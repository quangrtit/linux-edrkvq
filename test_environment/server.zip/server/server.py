# # Description: Simple HTTPS Server with mTLS support

# import http.server
# import ssl
# import argparse
# import socket
# import json
# import threading
# from http.server import ThreadingHTTPServer

# IOC_LIST = []
# STOP_SIGNALS = set()
# # Get local IP address
# def get_local_ip():
#     s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#     try:
#         # Makes connection to 1.1.1.1 to find local machine IP (E.g. 192.168.10.200)
#         s.connect(('1.1.1.1', 1))
#         local_ip = s.getsockname()[0]
#     except Exception:
#         # Fallback to localhost IP if external IP detection fails
#         local_ip = '127.0.0.1'
#     finally:
#         s.close()
#     return local_ip
# class RequestHandler(http.server.BaseHTTPRequestHandler):
#     def _set_headers(self, code=200):
#         self.send_response(code)
#         self.send_header("Content-Type", "application/json")
#         self.end_headers()

#     def do_GET(self):
#         if self.path.startswith("/ioc"):
#             # Agent polls IOC
#             self._set_headers()
#             self.wfile.write(json.dumps({"ioc": IOC_LIST}).encode())
#         elif self.path.startswith("/stop"):
#             # Agent polls stop command
#             agent_id = self.headers.get("X-Agent-ID", "")
#             if "ALL" in STOP_SIGNALS or agent_id in STOP_SIGNALS:
#                 self._set_headers()
#                 self.wfile.write(json.dumps({"action": "stop"}).encode())
#             else:
#                 self._set_headers()
#                 self.wfile.write(json.dumps({"action": "continue"}).encode())
#         else:
#             self._set_headers(404)
#             self.wfile.write(json.dumps({"error": "not found"}).encode())

#     def do_POST(self):
#         content_length = int(self.headers.get('Content-Length', 0))
#         body = self.rfile.read(content_length).decode()
#         try:
#             data = json.loads(body)
#         except Exception:
#             data = {}

#         if self.path == "/ioc":
#             # Add IOC
#             ioc = data.get("ioc")
#             if ioc:
#                 IOC_LIST.append(ioc)
#                 self._set_headers(201)
#                 self.wfile.write(json.dumps({"status": "ioc added"}).encode())
#             else:
#                 self._set_headers(400)
#                 self.wfile.write(json.dumps({"error": "missing ioc"}).encode())

#         elif self.path == "/stop":
#             # Issue stop command
#             agent_id = data.get("agent_id")
#             agent_id = 1
#             if agent_id:
#                 STOP_SIGNALS.add(agent_id)
#             else:
#                 STOP_SIGNALS.add("ALL")
#             self._set_headers(200)
#             self.wfile.write(json.dumps({"status": "stop issued"}).encode())
#         else:
#             self._set_headers(404)
#             self.wfile.write(json.dumps({"error": "not found"}).encode())

# # HTTPS Server, gets parsed arguments
# def run_server(port, certfile, keyfile, cafile, listen_ip, enable_mtls):
#     local_ip = get_local_ip() if listen_ip == '0.0.0.0' else listen_ip
#     server_address = (local_ip, port)
#     # httpd = http.server.HTTPServer(server_address, RequestHandler)
#     httpd = ThreadingHTTPServer(server_address, RequestHandler)
#     cert_reqs_option = ssl.CERT_REQUIRED if enable_mtls else ssl.CERT_NONE
#     httpd.socket = ssl.wrap_socket(
#         httpd.socket,
#         server_side=True,
#         certfile=certfile,
#         keyfile=keyfile,
#         cert_reqs=cert_reqs_option,
#         ca_certs=cafile if enable_mtls else None
#     )

#     print(f"Server running on: https://{local_ip}:{port}/")
#     def admin_loop():
#         while True:
#             cmd = input("Enter command (ioc <value> | stop <agent_id|ALL> | quit): ").strip()
#             if not cmd:
#                 continue
#             if cmd.lower() == "quit":
#                 print("Shutting down server...")
#                 httpd.shutdown()
#                 break
#             elif cmd.startswith("ioc "):
#                 val = cmd.split(" ", 1)[1]
#                 IOC_LIST.append(val)
#                 print(f"[Admin] Added IOC: {val}")
#             elif cmd.startswith("stop "):
#                 target = cmd.split(" ", 1)[1]
#                 STOP_SIGNALS.add(target)
#                 print(f"[Admin] Issued stop to: {target}")
#             else:
#                 print("[Admin] Unknown command")
#     threading.Thread(target=admin_loop, daemon=True).start()
#     httpd.serve_forever()

import http.server, ssl, argparse, socket, json, threading, time
from http.server import ThreadingHTTPServer

STOP_SIGNALS = set()

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('1.1.1.1', 1))
        local_ip = s.getsockname()[0]
    except Exception:
        local_ip = '127.0.0.1'
    finally:
        s.close()
    return local_ip

class RequestHandler(http.server.BaseHTTPRequestHandler):
    def _set_headers_sse(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/events"):
            self._set_headers_sse()

            if "ALL" in STOP_SIGNALS:
                msg = 'data: {"action": "stop"}\n\n'
            else:
                msg = 'data: {"action": "continue"}\n\n'

            try:
                self.wfile.write(msg.encode())
                self.wfile.flush()
            except Exception:
                pass  # client disconnected

            # Đóng sau khi gửi 1 lần
        else:
            self.send_response(404)
            self.end_headers()

def run_server(port, certfile, keyfile, cafile, listen_ip, enable_mtls):
    local_ip = get_local_ip() if listen_ip == '0.0.0.0' else listen_ip
    server_address = (local_ip, port)
    httpd = ThreadingHTTPServer(server_address, RequestHandler)
    cert_reqs_option = ssl.CERT_REQUIRED if enable_mtls else ssl.CERT_NONE
    httpd.socket = ssl.wrap_socket(
        httpd.socket,
        server_side=True,
        certfile=certfile,
        keyfile=keyfile,
        cert_reqs=cert_reqs_option,
        ca_certs=cafile if enable_mtls else None
    )

    def admin_loop():
        while True:
            cmd = input("Enter command (stop | quit): ").strip()
            if cmd.lower() == "quit":
                print("Shutting down server...")
                httpd.shutdown()
                break
            elif cmd.lower() == "stop":
                STOP_SIGNALS.add("ALL")
                print("[Admin] Stop issued to ALL")
            else:
                print("[Admin] Unknown command")

    threading.Thread(target=admin_loop, daemon=True).start()
    print(f"Server running on: https://{local_ip}:{port}/events")
    httpd.serve_forever()

# Main function to parse command line arguments
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Start a simple HTTPS server with optional mTLS.')
    parser.add_argument('-p', '--port', type=int, required=True, help='The port to listen on.')
    parser.add_argument('-c', '--certfile', type=str, required=True, help='Server certificate file.')
    parser.add_argument('-k', '--keyfile', type=str, required=True, help='Server private key file.')
    parser.add_argument('-a', '--cafile', type=str, help='CA certificate file for client verification.')
    parser.add_argument('-l', '--listen', type=str, default='127.0.0.1', help='IP address to listen on. Defaults to 127.0.0.1.')
    parser.add_argument('-m', '--mtls', action='store_true', help='Enable mutual TLS (mTLS). If not provided, mTLS will be disabled.')

    args = parser.parse_args()
    run_server(args.port, args.certfile, args.keyfile, args.cafile, args.listen, args.mtls)